#!/bin/bash

bash Mar10.sh
bash Mar12.sh
bash Mar15.sh
wc -l Dealers_working_during_losses


